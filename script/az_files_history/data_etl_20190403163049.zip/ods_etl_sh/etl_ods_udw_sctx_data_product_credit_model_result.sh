#!/bin/bash
CONNECTURL='jdbc:mysql://rr-bp1hjbv8wmon00sm86o.mysql.rds.aliyuncs.com:3306/sctx_data_product?tinyInt1isBit=false&characterEncoding=utf-8&autoReconnect=true&zeroDateTimeBehavior=convertToNull'
USERNAME=datawarehouse
PASSWORD=Sz5X#3K06J
#table.conf
mysql_database=sctx_data_product
mysql_table=credit_model_result
hive_external_table=ods_udw_sctx_data_product_credit_model_result

sqltemp=`cat /home/dispatch/Project/data-etl-sloth/schedule/etl_script/etl/ods_mysql_hive/ods_regular_table/etl_ods_udw_sctx_data_product_credit_model_result.sql`
v_dt=$1
end_dt=$2
#下面是基础查询语句 拼接 where条件
sql="$sqltemp where (a.time_inst>="\"$v_dt\"" and a.time_inst< "\"$end_dt\"") or (a.time_upd>="\"$v_dt\"" and a.time_upd< "\"$end_dt\"") and "\$CONDITIONS""
#分区指定为今日
 v_externalTablePartition=`date +%Y%m%d`
 

sqoop import --connect $CONNECTURL --username $USERNAME --password $PASSWORD --query "$sql" --target-dir "/user/hive/warehouse/ods/"$hive_external_table"/"$v_externalTablePartition --num-mappers 1 --as-parquetfile --driver com.mysql.jdbc.Driver 
hdfs dfs -mv /user/hive/warehouse/ods/$hive_external_table/$v_externalTablePartition /user/hive/warehouse/ods/$hive_external_table/dt=$v_externalTablePartition 
hdfs dfs -chmod -R  777 /user/hive/warehouse/ods/$hive_external_table/dt=$v_externalTablePartition 
beeline -u "jdbc:hive2://10.50.40.4:10000/ods" -n hive -p asdasd110.0 -e "msck repair table ods.ods_udw_sctx_data_product_credit_model_result"
