
#!/bin/bash
v_externalTablePartition=`date +%Y%m%d`
hdfs dfs -test -e /user/hive/warehouse/ods/ods_bdw_beadwalletloan_bw_zl_contact_region/dt=$v_externalTablePartition
if [ $? -eq 0 ];then
echo "exsit"
hdfs dfs -rm -r /user/hive/warehouse/ods/ods_bdw_beadwalletloan_bw_zl_contact_region/dt=$v_externalTablePartition
else 
echo "not exsit"
fi
if [ '20190307' = $v_externalTablePartition ];then 
 start_dt=2016-01-01
 end_dt=`date '+%F '"00:00:00"`
else start_dt=`date -d"-1 day" '+%F '"00:00:00"` end_dt=`date '+%F '"00:00:00"`
fi 
sh /home/dispatch/Project/data-etl-sloth/script/az_files/repeat/ods_etl_sh/etl_ods_bdw_beadwalletloan_bw_zl_contact_region.sh "$start_dt" "$end_dt"  > /data/disk13/logs/dispatch/logs/sh/etl_ods_bdw_beadwalletloan_bw_zl_contact_region.log 2>&1
if [ -f "/data/disk13/logs/dispatch/logs/sh/etl_ods_bdw_beadwalletloan_bw_zl_contact_region.log" ];then
result=`grep -nE 'ERROR:|Error ' /data/disk13/logs/dispatch/logs/sh/etl_ods_bdw_beadwalletloan_bw_zl_contact_region.log`
if [ ${#result} -gt 0 ];then
exit 22
else exit 0
fi
else 
exit 22
fi

